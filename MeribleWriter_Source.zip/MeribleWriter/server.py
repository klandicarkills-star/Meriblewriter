import storage
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from io import BytesIO
from zipfile import ZipFile, ZIP_DEFLATED
from xml.sax.saxutils import escape
import json, os, re

ROOT=Path(__file__).resolve().parent
class Handler(SimpleHTTPRequestHandler):
    def __init__(self,*args,**kwargs): super().__init__(*args,directory=str(ROOT),**kwargs)
    def do_GET(self):
        if self.path == '/api/documents':
            try:
                data = storage.load()
                self.send_json(data if data is not None else {
                    "docs": [], "current": None
                })
            except Exception as e:
                self.send_error(500, str(e))
            return
        return super().do_GET()

    def send_json(self, obj):
        raw = json.dumps(obj).encode('utf-8')
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Length', str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_POST(self):
        if self.path == '/api/documents':
            try:
                n = int(self.headers.get('Content-Length', '0'))
                if not 0 < n <= 5_000_000:
                    self.send_error(413)
                    return
                payload = json.loads(self.rfile.read(n))
                self.send_json(storage.save(payload))
            except (ValueError, TypeError) as e:
                self.send_error(400, str(e))
            except Exception as e:
                self.send_error(500, str(e))
            return
        if self.path!='/export/docx': self.send_error(404);return
        try:
            n=int(self.headers.get('Content-Length','0'))
            if n>5_000_000: self.send_error(413);return
            data=json.loads(self.rfile.read(n))
            title=str(data.get('title','Document'))[:150]
            paragraphs=data.get('paragraphs',[])
            if not isinstance(paragraphs,list): raise ValueError('Invalid paragraphs')
            paragraphs=[str(p)[:100000] for p in paragraphs[:10000]]
            def para(s):
                return '<w:p><w:r><w:t xml:space="preserve">'+escape(s)+'</w:t></w:r></w:p>'
            document='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>'+para(title)+''.join(para(p) for p in paragraphs)+'<w:sectPr/></w:body></w:document>'
            b=BytesIO()
            with ZipFile(b,'w',ZIP_DEFLATED) as z:
                z.writestr('[Content_Types].xml','''<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>''')
                z.writestr('_rels/.rels','''<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>''')
                z.writestr('word/document.xml',document)
            raw=b.getvalue()
            filename=re.sub(r'[^a-zA-Z0-9_-]+','_',title).strip('_') or 'Document'
            self.send_response(200);self.send_header('Content-Type','application/vnd.openxmlformats-officedocument.wordprocessingml.document');self.send_header('Content-Disposition',f'attachment; filename="{filename}.docx"');self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
        except (ValueError,TypeError,KeyError) as e: self.send_error(400,str(e))
if __name__=='__main__':
    print('Merible Writer: http://127.0.0.1:8765',flush=True)
    ThreadingHTTPServer(('127.0.0.1',8765),Handler).serve_forever()
