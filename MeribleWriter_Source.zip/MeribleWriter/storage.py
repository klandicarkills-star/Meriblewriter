from pathlib import Path
from datetime import datetime, timezone
import json
import os
import threading

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
BACKUPS = DATA / "backups"
FILE = DATA / "documents.json"

LOCK = threading.RLock()

DATA.mkdir(exist_ok=True)
BACKUPS.mkdir(exist_ok=True)

def validate(payload):
    if not isinstance(payload, dict):
        raise ValueError("Invalid document library")

    docs = payload.get("docs")
    if not isinstance(docs, list):
        raise ValueError("Missing documents")

    if len(docs) > 10000:
        raise ValueError("Too many documents")

    ids = set()

    for doc in docs:
        if not isinstance(doc, dict):
            raise ValueError("Invalid document")

        if not all(
            isinstance(doc.get(k), str)
            for k in ("id", "title", "html")
        ):
            raise ValueError("Invalid document fields")

        if not doc["id"] or doc["id"] in ids:
            raise ValueError("Invalid or duplicate ID")

        ids.add(doc["id"])

    current = payload.get("current")

    if current is not None and current not in ids:
        raise ValueError("Invalid current document")

    return {"docs": docs, "current": current}

def load():
    with LOCK:
        if not FILE.exists():
            return None

        return validate(
            json.loads(FILE.read_text(encoding="utf-8"))
        )

def save(payload):
    payload = validate(payload)

    with LOCK:
        raw = json.dumps(
            payload,
            ensure_ascii=False,
            indent=2
        )

        temp = DATA / "documents.tmp"
        with open(temp, "w", encoding="utf-8") as f:
            f.write(raw)
            f.flush()
            os.fsync(f.fileno())

        if FILE.exists():
            stamp = datetime.now(
                timezone.utc
            ).strftime("%Y%m%d-%H%M%S-%f")

            backup = BACKUPS / f"documents-{stamp}.json"
            backup.write_bytes(FILE.read_bytes())

        os.replace(temp, FILE)

        # Retain the most recent 20 snapshots.
        snapshots = sorted(
            BACKUPS.glob("documents-*.json")
        )

        for old in snapshots[:-20]:
            old.unlink()

    return {"ok": True}
